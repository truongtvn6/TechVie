const mongoose = require("mongoose");
const path = require("path");
require("dotenv").config({ path: path.join(__dirname, "../.env") });

const connectDB = require("../config/db");
const User = require("../models/User");
const UserModel = mongoose.models.User || mongoose.model("User");

const fixDatabasePhoneNumbers = async () => {
  console.log("Đang kết nối database...");
  await connectDB();

  try {
    const result = await UserModel.updateMany(
      { phone: "Chưa cung cấp" },
      { $set: { phone: "" } }
    );
    console.log(`🎉 Thành công! Đã cập nhật ${result.modifiedCount} người dùng từ 'Chưa cung cấp' thành chuỗi rỗng ''.`);
  } catch (error) {
    console.error("Lỗi khi cập nhật database:", error);
  } finally {
    await mongoose.disconnect();
    console.log("Đã đóng kết nối database.");
  }
};

fixDatabasePhoneNumbers();
