const mongoose = require("mongoose");
const path = require("path");
require("dotenv").config({ path: path.join(__dirname, "../.env") });
const connectDB = require("../config/db");

const readline = require("readline");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

function askConfirmation(query) {
  return new Promise((resolve) => rl.question(query, resolve));
}

async function resetDatabase() {
  console.log("⚠️  CẢNH BÁO: Reset database khi server đang chạy có thể gây lỗi hoặc xung đột dữ liệu.");
  const answer = await askConfirmation("👉 Bạn đã tắt server backend chưa? (y/N): ");
  
  if (answer.toLowerCase() !== 'y' && answer.toLowerCase() !== 'yes') {
    console.log("❌ Đã hủy thao tác reset database để bạn có thể tắt server.");
    rl.close();
    process.exit(0);
  }
  
  rl.close();

  console.log("➔ Đang kết nối tới database...");
  const conn = await connectDB();
  
  if (!conn) {
    console.error("❌ Không thể kết nối tới database. Vui lòng kiểm tra lại cấu hình MONGODB_URI.");
    process.exit(1);
  }

  try {
    console.log("➔ Đang thực hiện xóa toàn bộ database...");
    await mongoose.connection.db.dropDatabase();
    console.log("✔ Đã xóa (reset) toàn bộ database thành công!");
    
    console.log("\n=======================================================");
    console.log("📢 THÔNG BÁO: Vui lòng chạy lại các file setup ban đầu:");
    console.log("=======================================================");
    console.log("1. Khởi tạo tài khoản Admin:");
    console.log("   node scratch/first-setup/seedAdmin.js");
    console.log("\n2. Seed dữ liệu mẫu (nếu cần):");
    console.log("   node scratch/seed.js");
    console.log("=======================================================\n");

  } catch (error) {
    console.error("❌ Có lỗi xảy ra khi reset database:", error);
  } finally {
    await mongoose.disconnect();
    console.log("➔ Đã ngắt kết nối database.");
  }
}

resetDatabase();
