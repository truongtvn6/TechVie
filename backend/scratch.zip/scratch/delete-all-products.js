const mongoose = require('mongoose');
const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '../.env') });

// Database connection URI from environment or default fallback
const mongoURI = process.env.MONGODB_URI || "mongodb://127.0.0.1:27017/database_for_tmdt_01";

async function run() {
  try {
    console.log("Đang kết nối tới cơ sở dữ liệu MongoDB...");
    await mongoose.connect(mongoURI);
    console.log("Đã kết nối thành công. Tiến hành xóa toàn bộ sản phẩm...");
    
    // Clear products collection directly
    const result = await mongoose.connection.db.collection('products').deleteMany({});
    console.log(`Đã xóa sạch thành công ${result.deletedCount} sản phẩm khỏi cơ sở dữ liệu!`);
  } catch (error) {
    console.error("Lỗi trong quá trình xóa dữ liệu:", error);
  } finally {
    await mongoose.disconnect();
    console.log("Đã đóng kết nối MongoDB.");
  }
}

run();
