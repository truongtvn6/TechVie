const mongoose = require("mongoose");
const path = require("path");
require("dotenv").config({ path: path.join(__dirname, "../.env") });

const connectDB = require("../config/db");
const UserModel = mongoose.models.User || mongoose.model("User");

const inspectUsers = async () => {
  console.log("Đang kết nối database để kiểm tra...");
  await connectDB();

  try {
    const users = await UserModel.find({}).lean();
    if (users.length === 0) {
      console.log("Không có người dùng nào trong cơ sở dữ liệu.");
      return;
    }

    console.log(`\nDanh sách người dùng hiện tại (${users.length} tài khoản):`);
    const formattedUsers = users.map(u => ({
      ID: u._id.toString(),
      Username: u.username,
      Email: u.email,
      Role: u.role,
      VIP: u.vipStatus,
      Status: u.status,
      "Deleted?": u.isDeleted ? "Yes" : "No",
      "Created At": u.created_at
    }));

    console.table(formattedUsers);
  } catch (error) {
    console.error("Lỗi khi đọc dữ liệu:", error);
  } finally {
    mongoose.connection.close();
    console.log("Đã đóng kết nối database.");
  }
};

inspectUsers();
