const mongoose = require("mongoose");
const path = require("path");
require("dotenv").config({ path: path.join(__dirname, "../.env") });

const connectDB = require("../config/db");
const Contact = require("../models/Contact");
const ContactModel = mongoose.models.Contact || mongoose.model("Contact");

const deleteFakeMessage = async () => {
  await connectDB();
  try {
    const result = await ContactModel.deleteOne({ _id: "6a3c342a39f28f2ea3e23ffb" });
    console.log(`Đã xóa thành công ${result.deletedCount} thư góp ý spam của trantrungnamm@gmail.com.`);
  } catch (err) {
    console.error("Lỗi khi xóa:", err);
  } finally {
    await mongoose.disconnect();
  }
};

deleteFakeMessage();
