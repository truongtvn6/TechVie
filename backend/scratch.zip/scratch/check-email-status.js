const mongoose = require("mongoose");
const path = require("path");
require("dotenv").config({ path: path.join(__dirname, "../.env") });

const connectDB = require("../config/db");
const User = require("../models/User");
const Contact = require("../models/Contact");
const UserModel = mongoose.models.User || mongoose.model("User");
const ContactModel = mongoose.models.Contact || mongoose.model("Contact");

const checkEmailStatus = async () => {
  await connectDB();
  const targetEmail = "trantrungnamm@gmail.com".toLowerCase();

  const user = await UserModel.findOne({ email: targetEmail });
  const contact = await ContactModel.find({ email: targetEmail });

  console.log("=== KẾT QUẢ TÌM KIẾM ===");
  if (user) {
    console.log(`User: Tìm thấy tài khoản người dùng! ID: ${user._id}, Username: ${user.username}, Phone: ${user.phone}`);
  } else {
    console.log("User: Không tìm thấy tài khoản nào khớp với email này.");
  }

  if (contact.length > 0) {
    console.log(`Contact: Tìm thấy ${contact.length} thư góp ý của email này.`);
    contact.forEach((c, i) => {
      console.log(`  [${i + 1}] ID: ${c._id}, Tên: ${c.name}, Chủ đề: ${c.subject}, Nội dung: "${c.message}"`);
    });
  } else {
    console.log("Contact: Không tìm thấy thư liên hệ/góp ý nào từ email này.");
  }

  await mongoose.disconnect();
};

checkEmailStatus();
