const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const path = require("path");
require("dotenv").config({ path: path.join(__dirname, "../.env") });

const connectDB = require("../config/db");
const User = require("../models/User");
const UserModel = mongoose.models.User || mongoose.model("User");

const seedUsers = async () => {
  console.log("Đang kết nối database...");
  await connectDB();

  try {
    console.log("Đang làm sạch bộ sưu tập người dùng (users)...");
    await UserModel.deleteMany({});

    console.log("Đang mã hóa mật khẩu mẫu...");
    const salt = await bcrypt.genSalt(10);
    const adminPassword = await bcrypt.hash("admin123", salt);
    const userPassword = await bcrypt.hash("123456", salt);

    const mockUsers = [
      {
        username: "admin",
        email: "admin@techvie.com",
        password: adminPassword,
        phone: "0987654321",
        role: "admin",
        vipStatus: "Premium",
        status: "active",
      },
      {
        username: "mintz",
        email: "mintzinfinity898@gmail.com",
        password: userPassword,
        phone: "0123456789",
        role: "user",
        vipStatus: "Premium",
        status: "active",
      },
      {
        username: "guest_user",
        email: "guest@techvie.com",
        password: userPassword,
        phone: "0909123456",
        role: "user",
        vipStatus: "Normal",
        status: "active",
      },
      {
        username: "blocked_user",
        email: "blocked@techvie.com",
        password: userPassword,
        phone: "0909000111",
        role: "user",
        vipStatus: "Normal",
        status: "blocked",
      }
    ];

    console.log("Đang chèn dữ liệu mẫu vào MongoDB...");
    await UserModel.insertMany(mockUsers);
    console.log("🎉 Seeding dữ liệu thành công!");
  } catch (error) {
    console.error("Lỗi khi seeding dữ liệu:", error);
  } finally {
    mongoose.connection.close();
    console.log("Đã đóng kết nối database.");
  }
};

seedUsers();
