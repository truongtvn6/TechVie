const mongoose = require("mongoose");
const path = require("path");
require("dotenv").config({ path: path.join(__dirname, "../.env") });

const connectDB = require("../config/db");
const Order = require("../models/Order");

const checkOrders = async () => {
  await connectDB();
  const allOrders = await Order.find({});
  console.log(`=== TỔNG CỘNG CÓ ${allOrders.length} ĐƠN HÀNG TRÊN DATABASE ===`);
  allOrders.forEach((o, i) => {
    console.log(`[${i + 1}] ID: ${o._id}, Email: "${o.email}", status: "${o.status}", status_type: "${o.status_type}"`);
  });
  await mongoose.disconnect();
};

checkOrders();
